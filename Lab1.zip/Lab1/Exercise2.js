function max(a, b, c) {
    return Math.max(a, b, c);
}

console.log(max (1,0,1));
console.log(max (0,-10,-20));
console.log(max (1000,510,440));
